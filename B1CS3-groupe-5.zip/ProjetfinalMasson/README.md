Notre projet est le suivant : un site qui référence les restaurants et hôtels, et les classe de manière logique et ergonomique dans un script propre et performant.
Vous pourrez y découvrir des cuisines du monde entier.
Mais ce n’est pas tout : vous y trouverez également l’hébergement qui vous convient, grâce à notre large sélection d’adresses dans le secteur de l’hôtellerie.
Un système d’enregistrement client a été mis en place pour offrir une meilleure expérience d’utilisation de nos services.
Notre site a été conçu de manière à être optimisé pour le SEO, mais aussi accessible aux personnes en situation de handicap.
Enfin, il est entièrement sécurisé contre toute tentative d’intrusion.
Nous avons mis un point d'honneur à séparer chaque page par fonction afin d’assurer une expérience utilisateur fluide et agréable.