<?php
    include 'decoupe/hautindex.php';
?>

<main>
    <p>Trouvez les meilleurs restaurants via nos recommandations : <a href="pages/restaurants.php"> Notre sélection</a></p>
</main>

<?php
    include 'decoupe/bas.php';
?>