<?php 
$text = $GET_['recherche'];
echo htmlspecialchars($text);
//Permet d'affichier ce que l'utilisateur à écrit dans la barre de recherche comme demandé dans l'énoncé
?>