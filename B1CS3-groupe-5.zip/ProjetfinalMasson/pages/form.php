<?php

    if(isset($_POST['Nom']) && isset($_POST['Prénom']) && isset($_POST['Mail']) && isset($_POST['tel'])){
        $nom = htmlspecialchars($_POST['Nom']);
        $prenom = htmlspecialchars($_POST['Prénom']);
        $mail = htmlspecialchars($_POST['Mail']);
        $tel = htmlspecialchars($_POST['tel']);


        include '../include/cle.php';

        $sql = "INSERT INTO clients (nom, prenom, mail, tel) VALUES ('$nom', '$prenom', '$mail', '$tel')";

        $cle->query($sql);

        header('location:liste.php');
        
    } else {
        header('location: ../index.php');
    }
?>