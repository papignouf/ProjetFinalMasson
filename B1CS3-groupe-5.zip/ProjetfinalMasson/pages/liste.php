<?php 
    include '../decoupe/haut.php';
?>

<main>
    <h2>Liste des clients</h2>

    <thead>
        <tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Mail</th>
            <th>Tél</th>
        </tr>
    </thead>
    <tbody>
    <?php include '../include/cle.php';

    $sql = "SELECT * FROM clients";

    $reponse = $cle->query($sql);

    foreach($reponse AS $rep): ?>
        <table>
            <tr>
                <td><?= $rep['Nom'] ?></td>
                <td><?= $rep['Prénom']?></td>
                <td><?= $rep['Mail']?></td>
                <td><?= $rep['tel']?></td>
            </tr>

        </table>
    <?php endforeach; ?>
    </tbody>
    </table>
    </main>

    <?php 
        include '../decoupe/bas.php'; 
    ?>