<?php
    include '../decoupe/haut.php';
?>

<main>
    <h1>Découvrez une sélection d'hôtels d'exception à travers le monde, alliant luxe, confort et histoire pour des séjours inoubliables.</h1>

    <h2>
        Nom : Le Ritz-Carlton
        Distinction : Palace (⭐⭐⭐⭐⭐)
        Note : 9,6/10 (Booking)
        Description : Situé Place Vendôme, ce palace légendaire allie luxe intemporel et confort moderne, offrant des chambres somptueuses et des services haut de gamme. L'hôtel est connu pour son raffinement et son service personnalisé, et il a accueilli des célébrités et des chefs d'État pendant plus d'un siècle.
    </h2>
    <a href="<?= ROOT ?>images/ritz-carlton.jpg"><img src="../images/ritz-carlton.jpg" alt="Le Ritz-Carlton"></a>

    <h2>
        Nom : Hôtel de Crillon
        Distinction : Palace (⭐⭐⭐⭐⭐)
        Note : 9,4/10 (TripAdvisor)
        Description : Cet hôtel emblématique sur la Place de la Concorde, après une rénovation spectaculaire, offre une combinaison de confort moderne et de charme historique. L'hôtel de Crillon est une adresse incontournable pour ceux qui cherchent un luxe discret, un service personnalisé, et une situation exceptionnelle en plein cœur de Paris.
    </h2>
    <a href="<?= ROOT ?>images/hotelcrillon.jpg"><img src="../images/hotelcrillon.jpg" alt="L'hôtel de Crillon"></a>

    <h2>
        Nom : CitizenM, New York Times Square
        Distinction : 4 étoiles (⭐⭐⭐⭐)
        Note : 9/10 (Booking)
        Description : CitizenM New York Times Square est un hôtel moderne au style design, avec des chambres compactes mais ultra-confortables. Il est parfait pour les voyageurs à la recherche d'un bon rapport qualité-prix avec une expérience de luxe abordable. L'emplacement est idéal, juste à côté de Times Square, et l'hôtel propose un service unique, alliant technologie et confort.
    </h2>
    <a href="<?= ROOT ?>images/hotelcitizen.jpg"><img src="../images/hotelcitizen.jpg" alt="L'hôtel CitizenM"></a>

    <h2>
        Nom : The Hoxton, Amsterdam
        Distinction : 4 étoiles (⭐⭐⭐⭐)
        Note : 9,2/10 (Booking)
        Description : Le Hoxton Amsterdam offre une atmosphère branchée et chaleureuse, tout en proposant un design moderne dans un cadre historique. Cet hôtel est une parfaite combinaison de confort, d'emplacement central et de style, attirant une clientèle jeune et dynamique à la recherche d'un lieu convivial et moderne.
    </h2>
    <a href="<?= ROOT ?>images/hotelhoxton.jpg"><img src="../images/hotelhoxton.jpg" alt="The Hoxton"></a>

    <h2>
        Nom : Hotel Montefiore, Tel Aviv
        Distinction : 4 étoiles (⭐⭐⭐⭐)
        Note : 9,4/10 (TripAdvisor)
        Description : Cet hôtel boutique élégant combine un service de qualité avec un design sophistiqué. Situé dans le quartier branché de Tel Aviv, l'hôtel Montefiore se distingue par son atmosphère intime et son attention aux détails, offrant un cadre parfait pour explorer la ville tout en se relaxant dans un environnement de luxe discret.
    </h2>
    <a href="<?= ROOT ?>images/hotelmontefiore.jpg"><img src="../images/hotelmontefiore.jpg" alt="Hôtel Montefiore"></a>

    <h2>
        Nom : The Burj Al Arab Jumeirah, Dubaï
        Distinction : Palace (⭐⭐⭐⭐⭐)
        Note : 9,8/10 (TripAdvisor)
        Description : Ce symbole de luxe à Dubaï est l'un des hôtels les plus exclusifs au monde, avec sa structure en forme de voile. Le Burj Al Arab offre des suites somptueuses, des restaurants haut de gamme et des services exceptionnels, pour ceux qui recherchent l'expérience ultime du luxe.
    </h2>
    <a href="<?= ROOT ?>images/hoteldubai.jpg"><img src="../images/hoteldubai.jpg" alt="The Burj Al Arab Jumeirah"></a>
</main>

<?php
    include '../decoupe/bas.php';
?>