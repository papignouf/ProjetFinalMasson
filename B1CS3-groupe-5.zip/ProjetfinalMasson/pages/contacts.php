<?php
    include '../decoupe/haut.php';
?> 

<main>
        <form action="form.php" method="post" id="contact">

            <input type="radio" id="M" name="sex" value="M">
            <label for="M">M</label>

            <input type="radio" id="Mme" name="sex" value="Mme">
            <label for="Mme">Mme</label>

            <input type="radio" id="Mlle" name="sex" value="Mlle">
            <label for="Mlle">Mlle</label>

            <br>

            <label for="Nom">Nom</label>
            <input id="Nom" name="Nom" type="text" maxlength="100">

            <br>

            <label for="Prenom">Prénom</label>
            <input id="Prenom" name="Prénom" type="text" maxlength="100">

            <br>

            <label for="Mail">Mail</label>
            <input id="Mail" name="Mail" type="email" maxlength="100">

            <br>

            <label for="tel">N° de téléphone</label>
            <input id="tel" name="tel" type="tel">

            <br>

            <p>Comment nous avez vous connu?</p>

            <input id="pub" name="known" type="radio">
            <label for="pub">Pub</label>

            <br>

            <input id="relation" name="known" type="radio">
            <label for="relation">Relation</label>

            <br>

            <input id="notoriete" name="known" type="radio">
            <label for="notoriete">Notorieté</label>

            <br>

            <select required>
                <option disabled selected>Quels sont les régions qui vous intérèssent le plus ?</option>

                    <optgroup label="Nord">
                        <option value="1">Hauts-de-France</option>
                        <option value="2">Île-de-France</option>
                        <option value="3">Normandie</option>

                    </optgroup>

                    <optgroup label="Sud">
                        <option value="4">PACA</option>
                        <option value="5">Corse</option>
                        <option value="6">Occitanie</option>
                        <option value="7">Nouvelle-Aquitaine</option>
                        
                    </optgroup>

                    <optgroup label="Est">
                        <option value="8">Grand est</option>
                        <option value="9">Auvergnes-Rhône-Alpes</option>
                        <option value="10">Bourgogne-Franche-Comté</option>
                        
                    </optgroup>

                    <optgroup label="Ouest">
                        <option value="11">Bretagne</option>
                        <option value="12">Pays de la Loire</option>
                        <option value="13">Centre Val-de-la-Loire</option>
                    </optgroup>
            </select>

            <br>

            <p>Laissez nous toute information qui vous paraîtrait utile</p>
            <textarea rows="10" cols="100"></textarea>

            <br>

            
            <input type="submit" value="Envoyer le formulaire">
        </form>

</main>

<?php
    include '../decoupe/bas.php';
?>