<?php
    include '../decoupe/haut.php';
?>

<main>
    <h1>Découvrez les saveurs d'exception des restaurants étoilés du monde entier !</h1>

    <h2>Cuisine Japonaise 🇯🇵</h2>
    <p>Si vous cherchez plutôt une cuisine japonaise, avec ses saveurs délicates et l'élégance du dressage, laissez-vous séduire par des sushis d'exception et des créations raffinées.</p>

    <h3>
        Nom : L'Abysse - Pavillon Ledoyen

        Chef : Yannick Alléno

        Nombre d'étoiles : ⭐⭐

        Description détaillée : Installé dans le célèbre Pavillon Ledoyen, L'Abysse est le projet franco-japonais du chef multi-étoilé Yannick Alléno. Fasciné par l'art du sushi, Alléno a réuni une équipe de maîtres sushi pour créer une expérience unique à Paris. Le restaurant rend hommage à la pureté et à la précision des techniques nippones, tout en intégrant des ingrédients français d'exception. Chaque bouchée est une immersion dans la culture japonaise, avec la rigueur et la créativité caractéristiques de la haute gastronomie française.

        Lien : https://www.yannick-alleno.com/les-etablissements-du-groupe/abysse-paris

    </h3>
    <a href="<?= ROOT ?>images/japonaise.jpg"><img src="../images/japonaise.jpg" alt="Cuisine japonaise"></a>

    <h2>Cuisine italienne 🇮🇹</h2>
    <p>La dolce vita passe aussi par l'assiette : des pâtes maison aux desserts onctueux, découvrez la générosité et la finesse de la gastronomie italienne.</p>

    <h3>
        Nom : Il Carpaccio

        Chef : Oliver Piras et Alessandra Del Favero

        Nombre d'étoiles : ⭐

        Description détaillée : Niché dans le prestigieux hôtel Le Royal Monceau, Il Carpaccio est un hommage vibrant à la cuisine italienne authentique. Les chefs, originaires du Piémont et des Dolomites, s'inspirent de leurs racines pour proposer une carte gourmande et moderne. Produits de saison, recettes régionales revisitées et dolcezze raffinées sont au rendez-vous.

        Lien : https://restaurantsandbars.accor.com/fr/restaurant/A5D5_R001?utm_source=google+Maps&utm_medium=seo+maps&utm_campaign=seo+maps
    </h3>
    <a href="<?= ROOT ?>images/italienne.jpg"><img src="../images/italienne.jpg" alt="Cuisine italienne"></a>

    <h2>Cuisine espagnole 🇪🇸</h2>
    <p>Plongez dans la créativité débridée et l'énergie chaleureuse de la cuisine espagnole, où la tradition côtoie l'innovation culinaire.</p>

    <h3>
        Nom : Le Sergent Recruteur

        Chef : Antonin Bonnet

        Nombre d'étoiles : ⭐

        Description détaillée : Ce restaurant parisien puise dans la générosité de la cuisine ibérique, avec des clins d'œil aux tapas et produits espagnols. Antonin Bonnet, amoureux des terroirs, célèbre l'authenticité des ingrédients et la finesse des assaisonnements, dans un cadre intimiste au cœur du Marais.

        Lien : https://www.lesergentrecruteur.fr/
    </h3>
    <a href="<?= ROOT ?>images/espagnole.jpg"><img src="../images/espagnole.jpg" alt="Cuisine espagnole"></a>

    <h2>Cuisine thaïlandaise 🇹🇭</h2>
    <p>Vibrante et épicée, la cuisine thaïlandaise offre un feu d'artifice de saveurs et d'arômes exotiques, pour un dépaysement garanti.</p>

    <h3>
        Nom : Blue Elephant

        Chef : Khampan Pukdang

        Nombre d'étoiles : Non étoilé, mais renommé

        Description détaillée : Institution parisienne depuis plus de 35 ans, le Blue Elephant est une immersion dans la Thaïlande authentique. Décor luxuriant, senteurs d'épices et spécialités typiques transportent les convives au cœur de Bangkok, avec un souci du détail et une fidélité rare aux recettes traditionnelles.

        Lien : https://blueelephant.com/fr/
    </h3>
    <a href="<?= ROOT ?>images/thailandaise.jpg"><img src="../images/thailandaise.jpg" alt="Cuisine thailandaise"></a>

</main>

<?php
    include '../decoupe/bas.php';
?>