            <aside>
            <p>Restez informé de nos derniers ajouts en nous suivant sur les réseaux sociaux !</p> <br>
            <a href="facebook.com" target="_blank"><i class="fab fa-facebook"></i></a> <br> 
            <a href="twitter.com" target="_blank"><i class="fab fa-twitter"></i></a> <br>
            <a href="instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>  
            </aside>
            <footer>&copy;Copyright ; Mensa et Cubiculum, propriété d'un commun accord Touzellier/Pignon/Nusbaum</footer>
        </body>
    </html>