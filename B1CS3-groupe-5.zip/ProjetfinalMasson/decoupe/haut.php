<?php
define('ROOT', '/ProjetfinalMasson/');
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="../css/style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Venez découvrir notre projet final en Masson">
        <!--Pour ajoutez des icônes-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <title>Mensa et Cubiculum</title>
    </head>
    <body>
        <header>
            <a href="<?= ROOT ?>index.php"><img src="../images/logo.jpg" alt="Logo Mensa et Cubiculum"></a>
            <h1>Mensa et Cubiculum</h1>
            <form action="../pages/traitement.php" method="get">
                <input type="search" name="recherche" id="recherche" maxlength="200" placeholder="Recherche ...">
            </form>

 
        </header>
        <nav>
            <a href="<?= ROOT ?>index.php">Accueil</a> <br>
            <a href="<?= ROOT ?>pages/restaurants.php">Nos meilleurs restaurants</a><br>
            <a href="<?= ROOT ?>pages/hotels.php">Nos meilleurs hôtels</a><br>
            <a href="<?= ROOT ?>pages/contacts.php">Nous contacter</a>
 
        </nav>